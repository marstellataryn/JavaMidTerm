Inport daysAndDates.DaysOfWeek;

public class TestDaysOfWeek {

	public static void main(String[] args) {
		System.out.println("Days Of week: ");
		for (int i = 0;i < 8;i++) {
			System.out.println("Number: " + i + "\tDay Of Week: " + DaysOfWeek.DayOfWeekStr(i) )
		}

	}

}
